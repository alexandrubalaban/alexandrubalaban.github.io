import com.buzzilla.webhose.client.WebhoseClient;
import com.buzzilla.webhose.client.WebhosePost;
import com.buzzilla.webhose.client.WebhoseQuery;
import com.buzzilla.webhose.client.WebhoseResponse;
import connection.OracleJDBC;

import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Created by Ionut on 25.05.2015.
 */
public class Webhose
{
    private WebhoseClient webhoseClient = new WebhoseClient("25ae2e07-ad8b-4e57-92b8-cb65885de5ac");
    private WebhoseQuery  webhoseQuery = new WebhoseQuery();
    private WebhoseResponse webhoseResponse = new WebhoseResponse();
    private OracleJDBC connectionJDBC = new OracleJDBC();

    private void setWebhoseQuerySites(){
       webhoseQuery.sites.add("thehackernews.com"); // -> titlu ok + text ok + links = null
        //webhoseQuery.sites.add("infoq.com"); // -> titlu ok + text ok + links = null
       // webhoseQuery.sites.add("reddit.com"); // -> titlu lipseste uneori + text ok + lins = null
        //webhoseQuery.sites.add("computerworld.com");
        //webhoseQuery.sites.add("cnet.com");
        //webhoseQuery.sites.add("bbc.com");

    }

    private void setWebhoseQuerySites(String sites){
            webhoseQuery.sites.add(sites);
    }
    private void setWebhoseQueryTerms(String terms){
        webhoseQuery.someTerms.add(terms);
    }

    private void setWebhoseQueryTerms(){
        webhoseQuery.someTerms.add("php");
        webhoseQuery.someTerms.add("java");
        webhoseQuery.someTerms.add("c++");
        webhoseQuery.someTerms.add("it");
        webhoseQuery.someTerms.add("vpn");
        webhoseQuery.someTerms.add("pc");
        webhoseQuery.someTerms.add("laptop");
        webhoseQuery.someTerms.add("programming");
        webhoseQuery.someTerms.add("software");
        webhoseQuery.someTerms.add("hardware");
        webhoseQuery.someTerms.add("windows");
    }
    public static void viewTable(Connection con)
            throws SQLException {

        Statement stmt = null;
        String query = "select id,title,bodyText,averagerate from articles";
        try {
            stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                int coffeeName = rs.getInt("id");
                String  supplierID = rs.getString("title");
                String  price = rs.getString("bodyText");
                int sales = rs.getInt("averagerate");
                System.out.println(coffeeName + "\t" + supplierID +
                        "\t" + price + "\t" + sales +
                        "\t");
            }
        } catch (SQLException e ) {
            //JDBCTutorialUtilities.printSQLException(e);
            System.out.println(e.getMessage());
        } finally {
            if (stmt != null) { stmt.close(); }
        }
    }

    public WebhoseClient getWebhoseClient() {
        return webhoseClient;
    }

    public WebhoseQuery getWebhoseQuery() {
        return webhoseQuery;
    }

    public WebhoseResponse getWebhoseResponse() {
        return webhoseResponse;
    }

    public static void main(String[] args) throws FileNotFoundException, UnsupportedEncodingException, SQLException
    {
        Webhose webhose  = new Webhose();
       // webhose.connectionJDBC.makeConection();
        webhose.setWebhoseQuerySites();
        webhose.setWebhoseQueryTerms();
        OracleJDBC theOracleJDBC = new OracleJDBC();

        theOracleJDBC.setConnection(theOracleJDBC.makeConection());
        try {
            theOracleJDBC.setStatement(theOracleJDBC.getConnection().createStatement());
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }



        for(int i = 3;i < args.length;i++){
            webhose.setWebhoseQuerySites(args[i]);
        }

        ResultSet rs = theOracleJDBC.getStatement().executeQuery("select max(id) as IdMax from articles");
        int i =1;
        while (rs.next()) {
            i = rs.getInt("IdMax");
        }
       // System.out.println("id max " + i);


        rs = theOracleJDBC.getStatement().executeQuery("select name from categories where id = "+ args[1]);
        String categoryName = "";
        while (rs.next()) {
            categoryName = rs.getString("name");
        }

        rs = theOracleJDBC.getStatement().executeQuery("select name from tags where id = "+ args[2]);
        String tagName = "";
        while (rs.next()) {
            tagName = rs.getString("name");
        }


        rs = theOracleJDBC.getStatement().executeQuery("select max(id) as IdMax from article_types");
        int idArticleType =1;
        while (rs.next()) {
            idArticleType = rs.getInt("IdMax");
        }
        //System.out.println("id max " + i);

        webhose.setWebhoseQueryTerms(tagName);
        webhose.setWebhoseQueryTerms(categoryName);





        try {
                webhose.webhoseResponse = webhose.getWebhoseClient().search(webhose.webhoseQuery);
                System.out.println( "nr rez"+webhose.webhoseResponse.totalResults);
                int nr_art = 0;
                for (WebhosePost post : webhose.getWebhoseResponse().posts){
                    String text = post.text.replace("\'","\'\'");
                    String title = post.title.replace("\'","\'\'");
                    String url = post.url.replace("\'", "\'\'");
                    String  excerpt = text.substring(0,34);

                    String ss = "";
                    if(post.text.length() < 4000 && post.title.length() < 200 && post.url.length() < 500)
                    {

                        i++;
                        nr_art++;
                        System.out.println(i);
                        if(nr_art==100)System.exit(nr_art);
                        if(post.title.length() > 3){
                            ss += "Insert into articles values(" + i +",\'"+ title+"\'"+args[0]+",\'"+excerpt+"\',\'"+text+"\',\'"+url+"\',\'"+url+"\',"+0+","+"Sysdate,Sysdate,Sysdate)";
                            try {
                                theOracleJDBC.getStatement().executeUpdate("Insert into articles values(" + i +",\'"+ title+"\',"+args[0]+",\'"+excerpt+"\',\'"+text+"\',\'"+url+"\',\'"+url+"\',"+0+","+"Sysdate,Sysdate,Sysdate)");
                                idArticleType++;
                                theOracleJDBC.getStatement().executeUpdate("Insert into article_tag values(" + i+","+ args[2]+","+"sysdate,sysdate"+")");
                                theOracleJDBC.getStatement().executeUpdate("Insert into article_categories values(" + i+","+ args[1]+","+"sysdate,sysdate"+")");
                                theOracleJDBC.getStatement().executeUpdate("Insert into article_types values("+ idArticleType+"," + i +",\'"+ "text"+"\'"+","+"sysdate,sysdate"+")");
                            }
                            catch (SQLException e)
                            {
                                System.out.println(ss);
                                System.out.println(e.getMessage());

                            }
                        }
                        else {
                            ss +="Insert into articles values(" + i +",\' new article \',\'"+post.text+"\',"+0+",\'"+url+"\',\'"+post.url+"\',"+0+","+"Sysdate,Sysdate,Sysdate)";
                            try {
                                theOracleJDBC.getStatement().executeUpdate("Insert into articles values(" + i +",\'"+"New Article"+"\',"+args[0]+",\',"+excerpt+"\',\'"+text+"\',\'"+url+"\',\'"+url+"\',"+0+","+"Sysdate,Sysdate,Sysdate)");
                                idArticleType++;
                                theOracleJDBC.getStatement().executeUpdate("Insert into article_tag values(" + i+","+ args[2]+","+"sysdate,sysdate"+")");
                                theOracleJDBC.getStatement().executeUpdate("Insert into article_categories values(" + i+","+ args[1]+","+"sysdate,sysdate"+")");
                                theOracleJDBC.getStatement().executeUpdate("Insert into article_types values("+ idArticleType+"," + i +",\'"+ "text"+"\'"+","+"sysdate,sysdate"+")");
                            }
                            catch (SQLException e){
                                System.out.println(ss);
                                System.out.println(e.getMessage());
                            }
                        }

                    }
                }
            } catch (Exception e){
            System.out.println(e.getMessage());
        }
    }

}
